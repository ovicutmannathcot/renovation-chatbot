
async function sendMessage() {
    const inputField = document.getElementById('userInput');
    const message = inputField.value.trim();
    if (!message) return;

    const chatbox = document.getElementById('chatbox');
    chatbox.innerHTML += `<div><strong>Вы:</strong> ${message}</div>`;
    chatbox.scrollTop = chatbox.scrollHeight;
    inputField.value = '';

    const res = await fetch('https://your-backend-url/chat', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ user_id: 'user123', message })
    });
    const data = await res.json();

    chatbox.innerHTML += `<div><strong>Бот:</strong> ${data.reply}</div>`;
    chatbox.scrollTop = chatbox.scrollHeight;
}
