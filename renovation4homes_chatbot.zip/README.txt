
🛠️ Установка Чат-бота RENOVATION 4HOMES INC на WordPress
---------------------------------------------------------

1. Загрузка файлов:
-------------------
- chat.html, style.css и script.js разместите на любом хостинге или в WordPress через iframe.
- app.py — это серверная часть на Python + Flask (необходим Python 3.8+).

2. Установка Python зависимостей:
---------------------------------
pip install flask openai flask-cors

3. Добавьте свой API ключ от OpenAI в app.py:
---------------------------------------------
openai.api_key = 'ВАШ_КЛЮЧ'

4. Запуск сервера:
------------------
python app.py

5. Вставка на сайт WordPress:
-----------------------------
Используйте iframe:
<iframe src="https://yourhost.com/chat.html" width="350" height="500" style="border:none;"></iframe>

6. Просмотр истории чата:
-------------------------
База данных chat_history.db содержит историю: ID пользователя, вопрос, ответ, дата/время.

