
from flask import Flask, request, jsonify
import openai
import sqlite3
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

openai.api_key = 'YOUR_OPENAI_API_KEY'

# Create DB for storing chat history
def init_db():
    conn = sqlite3.connect('chat_history.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS chats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    message TEXT,
                    response TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )''')
    conn.commit()
    conn.close()

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    user_id = data.get('user_id', 'anonymous')
    user_message = data.get('message', '')

    # Prompt for ChatGPT
    messages = [
        {"role": "system", "content": "Ты — дружелюбный помощник компании RENOVATION 4HOMES INC. Помогаешь людям на сайте с вопросами по вакансиям и трудоустройству."},
        {"role": "user", "content": user_message}
    ]

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=messages
    )
    reply = response.choices[0].message.content.strip()

    # Save to DB
    conn = sqlite3.connect('chat_history.db')
    c = conn.cursor()
    c.execute("INSERT INTO chats (user_id, message, response) VALUES (?, ?, ?)", (user_id, user_message, reply))
    conn.commit()
    conn.close()

    return jsonify({'reply': reply})

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
